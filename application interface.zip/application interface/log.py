from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtUiTools import QUiLoader
# from mainwindow import *

class Stats:

    def __init__(self):
        # 从文件中加载UI定义

        # 从 UI 定义中动态 创建一个相应的窗口对象
        # 注意：里面的控件对象也成为窗口对象的属性了
        # 比如 self.ui.button , self.ui.textEdit
        self.ui = QUiLoader().load('ui_login.py')

        self.ui.login_btn.clicked.connect(self.login)

    def login(self):
        username = self.ui.username_textEdit.text()
        password = self.ui.password_textEdit.text()
        if username == 'admin' and password == 'admin':
            QMessageBox.information(
                self.ui,
                '登录',
                '登录成功！')
        else:
            QMessageBox.critical(
                self.ui,
                '登录',
                '登录失败，请重新输入！')


app = QApplication([])
stats = Stats()
stats.ui.show()
app.exec()