#self.pushButton.setShortcut(_translate("MainWindow", "enter")) #设置快捷键
import sys
 
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QImage, QPixmap, QKeyEvent
 
from PyQt5.QtWidgets import QMessageBox

from KUANG import Ui_MainWindow
import threading
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QMainWindow, QApplication, QAbstractItemView, QHeaderView, QLabel, QTableWidgetItem, \
    QMessageBox, QFileDialog
from KUANG import Ui_MainWindow
from ui_login import Ui_Name

import chuli
import matplotlib.pyplot as plt
import ui_login
from main import uic

import sys
import threading

from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QMainWindow, QApplication, QAbstractItemView, QHeaderView, QLabel, QTableWidgetItem, \
    QMessageBox, QFileDialog
# from KUANG import Ui_MainWindow
from ui_login import Ui_Name
# import chuli
import matplotlib.pyplot as plt
from main import uic
# from duqumain import DENGLU

class User(QtWidgets.QMainWindow, Ui_Name):
    def __init__(self):
        super(User, self).__init__()
        self.setupUi(self)  # 创建窗体对象
        self.init()
        self.admin = "spectral"
        self.Password = "1234"
 
    def init(self):
        self.pushpushbutton.clicked.connect(self.login_button) #连接槽
 
    def login_button(self):
        if self.keyinput.text()=="":
            QMessageBox.warning(self, 'Warning', 'The password cannot be none,please retype！')
            return None
 
        # if  self.password == self.lineEdit.text():
        if (self.keyinput.text()== self.Password) and self.userinput.text()== self.admin:


            self.windoww=DENGLU()
             
            self.windoww=DENGLU()
            self.windoww.show()
            # 2关闭本窗口
            
        else:
            QMessageBox.critical(self, 'Error', 'The password is error！')
            self.userinput.clear()
            self.keyinput.clear()
            return None
        # 关闭事件
    # 关闭事件
    def closeEvent(self, event):
        reply = QMessageBox.question(self,
                                     '退出',
                                     "Are you want to quit？",
                                     QMessageBox.Yes | QMessageBox.No,
                                     QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.close()
            event.accept()
        else:
            event.ignore()

from recognizition import MyWindow
 
if __name__ == '__main__':
    from PyQt5 import QtCore
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)#自适应分辨率
 
    app = QtWidgets.QApplication(sys.argv)
    login_window = User()
    main_window=DENGLU()
    
    login_window.show()
    
    sys.exit(app.exec_())
    
 

